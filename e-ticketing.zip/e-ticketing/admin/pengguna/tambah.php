<?php

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if(isset($_POST["tambah"])){
    if(tambah($_POST) > 0 ){
        echo "
            <script type='text/javascript'>
                setTimeout(function () { 
                swal({
                        title: 'Berhasil',
                        type: 'success',
                        timer: 3200,
                        showConfirmButton: true
                    });   
                },10);  
            window.setTimeout(function(){ 
              window.location.replace('index.php');
            } ,1000); 
            </script>";   
    }else{
        echo"
            <script type='text/javascript'>
                alert('Yhaa .. data pengguna gagal ditambahkan :(')
                window.location = 'index.php'
            </script>
        ";
    }
}



?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna</title>
    <link rel="stylesheet" href="../../assets/style/edit.css">

</head>
<body>

<div class="main">
    <h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
    <h1>Tambah Pengguna</h1>
    
    <form action="" method="POST">
        <label for="username">Username</label><br />
        <input type="text" name="username" id="username" class="form-control"><br /> <br />
    
        <label for="nama_lengkap">Nama Lengkap</label><br />
        <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control"><br /> <br />
    
        <label for="password">Password</label><br />
        <input type="password" name="password" id="password" class="form-control"><br /> <br />
    
        <label for="roles">Roles</label><br />
        <select name="roles" id="roles">
            <option value="Petugas">Petugas</option>
            <option value="Penumpang">Penumpang</option>
        </select><br /> <br />
    
        <button type="submit" name="tambah">Tambah</button>
    </form>
</div>


</body>
</html>

// echo "<script type='text/javascript'>" 
        //         swal({
        //             "title: 'Berhasil'\n" .
        //             "type: 'success'\n" .
        //             "timer: 3200,\n" .
        //             "showConfirmButton: true\n"
        //         },10); 
        //         "window.location.replace('index.php')";
        //     "</script>";