<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Admin</title>
</head>
<style>
  body {
    display: flex;
    height: 100vh;
    margin: 0;
    background-color: #f5f5f5;
}

.sidebar-admin {
    width: 200px;
    height: 200%;
    background-color: #333;
    color: #fff;
    padding: 30px;
    border-radius: 5px;
}

.sidebar-admin a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.sidebar-admin a:hover {
    background-color: #50a3a2;
}

.sidebar-admin a.active {
    background-color: #50a3a2;
}  
</style>
<body>
    <div class="sidebar-admin">
        <a href="index.php">Dashboard</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/pengguna/">Data Pengguna</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/maskapai/">Data Maskapai</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/kota/">Data Kota</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/rute/">Data Rute</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/jadwal/">Data Jadwal Penerbangan</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/order/">Pemesanan Tiket</a>&nbsp;&nbsp;
        <a href="/e-ticketing/logout.php" onClick="return confirm('Apakah anda yakin ingin logout?')">Logout</a>
    </div>
</body>
</html>