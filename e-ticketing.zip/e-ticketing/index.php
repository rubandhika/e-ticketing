<?php require 'layouts/navbar.php'; ?>

<?php 

$jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");   

if (isset($_GET['query']) && !empty($_GET['query'])) {
    $search_query = $_GET['query'];
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE nama_maskapai LIKE '%$search_query%' OR rute_asal LIKE '%$search_query%' OR rute_tujuan LIKE '%$search_query%' ORDER BY tanggal_pergi, waktu_berangkat");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Penerbangan - E Ticketing</title>
    <link rel="stylesheet" href="assets/style/style.css">
</head>

<style>

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
}

.list-tiket-pesawat {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

h1 {
    text-align: center;
}

.search { 
    display: flex; 
    justify-content: center; 
    margin-bottom: 30px; 
}

.search_query { 
    width: 500px; 
    height: 40px; 
    border-radius: 5px; 
    border: 1px solid #ccc; 
    padding: 0 10px; 
    margin-right: 10px; 
    }

button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.card-tiket-pesawat:hover { 
        transform: translateY(-10px); 
    }

    .wrapper-tiket-pesawat { 
        display: flex; 
        flex-wrap: wrap; 
        justify-content: center; 
        width: 100%; 
        max-width: 1200px; 
    }

.card-tiket-pesawat { 
        width: 300px; 
        height: 250px; 
        background-color: #fff; 
        box-shadow: 0 2px 100px rgba(0, 0, 0, 0.1); 
        border-radius: 5px; 
        margin: 10px; 
        text-align: center; 
        transition: transform 0.3s ease; 
    }

.card-tiket-pesawat:hover {
    box-shadow: 0 0 40px rgba(0, 0, 0, 0.2);
}

.image img {
    display: block;
    margin: 0 auto;
}

.nama-maskapai {
    font-weight: bold;
    text-align: center;
    margin: 10px 0;
}

.tanggal-berangkat, .waktu-berangkat, .rute-penerbangan, .text-harga {
    text-align: center;
    margin: 5px 0;
}

</style>

<body>
    <div class="list-tiket-pesawat">
        <h1>Jadwal Penerbangan - E Ticketing</h1>
    
        <form action="index.php" method="get" class="search">
            <input type="text" class="search_query" name="query" required placeholder="Silahkan pilih jadwal penerbangan">
            <button type="submit">Search</button>
        </form>

        <div class="wrapper-tiket-pesawat">
            <?php foreach($jadwalPenerbangan as $data) : ?>
                <div class="card-tiket-pesawat">
                    <a href="detail.php?id=<?= $data["id_jadwal"]; ?>" style="text-decoration: none; color: #000;">
                        <div class="image"><img src="assets/images/<?= $data["logo_maskapai"]; ?>"  width="80"></div>
                        <div class="nama-maskapai"><?= $data["nama_maskapai"]; ?></div>
                        <div class="tanggal-berangkat"><?= $data["tanggal_pergi"]; ?></div>
                        <div class="waktu-berangkat"><?= $data["waktu_berangkat"]; ?> - <?= $data["waktu_tiba"]; ?></div>
                        <div class="rute-penerbangan"><?= $data["rute_asal"] ?> - <?= $data["rute_tujuan"]; ?></div>
                        <div class="text-harga">Rp <?= number_format($data["harga"]); ?></div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div> 
    </div>
    
</body>
</html>










<!-- <style>
    .list-tiket-pesawat { 
        display: flex; 
        flex-direction: column; 
        align-items: center; 
        margin-top: 50px; 
    }

    .search { 
        display: flex; 
        justify-content: center; 
        margin-bottom: 30px; 
    }

    .search_query { 
        width: 500px; 
        height: 40px; 
        border-radius: 5px; 
        border: 1px solid #ccc; 
        padding: 0 10px; 
        margin-right: 10px; 
    }

    .wrapper-tiket-pesawat { 
        display: flex; 
        flex-wrap: wrap; 
        justify-content: center; 
        width: 100%; 
        max-width: 1200px; 
    }

    .card-tiket-pesawat { 
        width: 300px; 
        height: 250px; 
        background-color: #fff; 
        box-shadow: 0 2px 100px rgba(0, 0, 0, 0.1); 
        border-radius: 5px; 
        margin: 10px; 
        text-align: center; 
        transition: transform 0.3s ease; 
    }

    .card-tiket-pesawat:hover { 
        transform: translateY(-10px); 
    }

    .card-tiket-pesawat a { 
        text-decoration: none; 
        color: #000; 
        display: block; 
    }

    .image {
        width: 100px; 
        height: 100px; 
        margin: 20px auto; 
        overflow: hidden; 
        border-radius: 50%; 
    }

    .image img { 
        width: 100%; 
        height: auto; 
    }

    .nama-maskapai { 
        font-size: 18px; 
        font-weight;
    }
    
</style> -->