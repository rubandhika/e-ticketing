<?php require 'layouts/navbar.php'; ?>


<?php 

$id = $_GET["id"];

$jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE id_jadwal = '$id'")[0];




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail - e ticketing</title>
</head>
<style>
    /* Style untuk container detail produk */
.list-tiket-pesawat {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
    max-width: 600px;
}


.logo-maskapai img {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 0 auto;
}


.wrapper-detail-tiket-pesawat {
    margin-top: 20px;
}

.wrapper-detail-tiket-pesawat div {
    margin-bottom: 10px;
}

.wrapper-detail-tiket-pesawat .harga_tiket {
    font-weight: bold;
}

.wrapper-detail-tiket-pesawat form {
    margin-top: 20px;
}

.wrapper-detail-tiket-pesawat input[type="number"] {
    width: 60px;
    padding: 5px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.wrapper-detail-tiket-pesawat button {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.wrapper-detail-tiket-pesawat button:hover {
    background-color: #0056b3;
}

</style>
<body>

<div class="list-tiket-pesawat">
    <h1>Jadwal Penerbangan - E Ticketing</h1>
    <div class="wrapper-detail-tiket-pesawat">

        <div class="logo-maskapai"><img src="assets/images/<?= $jadwalPenerbangan["logo_maskapai"]; ?>" width="200px" alt="" srcset=""></div>

        <div class="nama_maskapai">nama maskapai : <?= $jadwalPenerbangan["nama_maskapai"]; ?> </div>

        <div class="rute_asal">rute asal : <?= $jadwalPenerbangan["rute_asal"]; ?> </div>

        <div class="rute_tujuan">rute tujuan : <?= $jadwalPenerbangan["rute_tujuan"]; ?> </div>

        <div class="tanggal_pergi">tanggal berangkat : <?= $jadwalPenerbangan["tanggal_pergi"]; ?> </div>

        <div class="waktu_berangkat">waktu berangkat : <?= $jadwalPenerbangan["waktu_berangkat"]; ?> </div>

        <div class="waktu_tiba">waktu tiba : <?= $jadwalPenerbangan["waktu_tiba"]; ?> </div>

        <div class="harga_tiket">harga : <?= $jadwalPenerbangan["harga"]; ?> </div>
        
        <div class="kapasitas">kapasitas kursi : <?= $jadwalPenerbangan["kapasitas_kursi"]; ?> </div>

        <form action="" method="post">
            <input type="number" name="qty" value="1">
            <button type="submit" name="pesan">pesan</button>
        </form>
    </div>
</div>

<?php

if(isset($_POST["pesan"])){
    if($_POST["qty"] > $jadwalPenerbangan["kapasitas_kursi"]){
        echo "
            <script type='text/javascript'>
                alert('Maaf, Kapasitas kamu melebihi stok yang tersedia');
                window.location = 'index.php';
            </script>
        ";
    }elseif ($_POST["qty"]<= 0){
        echo "
            <script type='text/javascript'>
                alert('beli setidaknya satu tiket');
                window.location = 'index.php';
            </script>
        ";
    }else{
        $qty = $_POST["qty"];
        $_SESSION["cart"][$id] = $qty;

        echo "
            <script type='text/javascript'>
                alert('Produk berhasil ditambahkan');
                window.location = 'cart.php';
            </script>
        ";
    }
}

?>
    
</body>
</html>
