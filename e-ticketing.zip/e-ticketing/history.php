<?php require 'layouts/navbar.php'; ?>
</div>
<?php 

$id_user = $_SESSION["id_user"];
$orderTiket = mysqli_query($conn, "SELECT order_tiket.id_order, order_tiket.struk, order_tiket.status, order_detail.id_order, order_detail.id_user, user.id_user FROM order_tiket INNER JOIN order_detail ON order_tiket.id_order = order_detail.id_order INNER JOIN user On order_detail.id_user = user.id_user WHERE user.id_user = '$id_user' GROUP BY order_tiket.id_order");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .list-tiket-pesawat {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        a {
            color: blue;
            text-decoration: none;
        }

        @media screen and (max-width: 600px) {
            .list-tiket-pesawat {
                padding: 10px;
            }

            table {
                font-size: 14px;
            }
        }
</style>
<body>
    
    <div class="list-tiket-pesawat mt-5">
        <h1>History - E Ticketing</h1>
        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>No Order</th>
                <th>Struk</th>
                <th>Status</th>
                <th>Opsi</th>
            </tr>
            <?php foreach($orderTiket as $data) : ?>
            <tr>
                <td><?= $data["id_order"]; ?></td>
                <td><?= $data["struk"]; ?></td>
                <td class="status">
                    <?php 
                        if($data["status"] == "Proses"){
                            ?>
                            <button class="status-pesanan proses">
                                <i class="fa-solid fa-arrow-progress"></i> Pemesanan sedang diproses <i class="fa-regular fa-face-smile"></i>
                            </button>
                            <?php
                        } else if($data["status"] == "Berhasil"){
                            ?>
                            <button class="status-pesanan diterima"> Pemesanan telah diterima</button>
                            <?php
                        } else if($data["status"] == "Gagal"){
                            ?>
                            <button class="status-pesanan ditolak">
                                <i class="fa-sharp fa-solid fa-triangle-exclamation"></i> Pemesanan ditolak, pastikan mengisi data dengan benar!
                            </button>
                            <?php
                        }
                    ?>
                </td>
                <td>
                    <a href="detailPemesanan.php?id=<?= $data["id_order"]; ?>">Detail</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    
</body>    
</html>

