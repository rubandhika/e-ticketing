<?php require 'layouts/navbar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>

</head>
<style>
    /* Style untuk section detail-breadcrumb */
.detail-breadcrumb {
    background-color: #f8f9fa;
    padding: 20px 0;
}

.detail-breadcrumb h3 {
    margin-bottom: 0;
    color: #333;
}

/* Style untuk section list tiket */
.list-ticket {
    padding: 20px 0;
}

.list-tiket-pesawat {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.list-tiket-pesawat h1 {
    font-size: 24px;
    margin-top: 0;
}

.card {
    margin-bottom: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
}

.card-body {
    padding: 20px;
}

/* Style untuk tombol checkout */
.btn-checkout {
    background-color: #28a745;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
}

/* Animasi untuk judul pada section detail-breadcrumb */
.detail-breadcrumb h3 {
    margin-bottom: 0;
    color: #333;
    animation: slideInDown 1s ease forwards;
}

@keyframes slideInDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* Efek hover untuk card */
.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

/* Animasi untuk tombol checkout */
.btn-checkout {
    transition: background-color 0.3s ease;
}

.btn-checkout:hover {
    background-color: #218838;
    transform: scale(1.05);
}


.btn-checkout:hover {
    background-color: #218838;
}

</style>
<body>
<section class="list-ticket">    
<div class="container">
  <div class="row">
        <div class="col-md-8">
            <div class="list-tiket-pesawat">
                <?php if (empty($_SESSION["cart"])) : ?>
                <h1>Belum ada tiket yang kamu pesan</h1>
                <?php else : ?>
                <?php foreach ($_SESSION["cart"] as $id_tiket => $kuantitas) : ?>
                    <?php $tiket = query("SELECT * FROM jadwal_penerbangan INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE id_jadwal = '$id_tiket'")[0]; ?>

                    <div class="card mb-3">
                    <div class="row g-0">
                        <div class="col-md-4">
                        <img src="assets/images/<?= $tiket["logo_maskapai"]; ?>" class="img-fluid rounded-start">
                        </div>
                        <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Nama Maskapai : <?= $tiket["nama_maskapai"]; ?></h5>
                            <p class="card-text">
                            <ul>
                                <li>Tanggal Pergi : <?= $tiket["tanggal_pergi"]; ?></li>
                                <li>Waktu Berangkat : <?= $tiket["waktu_berangkat"]; ?></li>
                                <li>Rute Penerbangan : <?= $tiket["rute_asal"] ?> - <?= $tiket["rute_tujuan"]; ?></li>
                            </ul>
                            </p>
                            <h5 class="card-title">Harga : Rp. <?= number_format($tiket["harga"]); ?></h5>
                            <h5 class="card-title">Jumlah Tiket : <?= $kuantitas; ?></h5>
                            <h5 class="card-title">Total : Rp. <?= number_format($tiket["harga"] * $kuantitas); ?></h5>
                        </div>
                        </div>
                    </div>
                    </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
        <div class="list-tiket-pesawat">
            <form action="" method="POST">
            <input type="hidden" name="id_user" value="<?= $_SESSION["id_user"]; ?>">
            <label for="nama_lengkap">Nama Pemesan : </label>
            <input type="text" style="background-color: #dedede; width: 170px;" value="<?= $_SESSION["nama_lengkap"]; ?>" disabled><br><br>
            <label for="">No Telepon : </label>
            <input type="text" style="background-color: #dedede; width: 170px;" placeholder="+62 832-5648-8891" disabled><br><br>
            <label for="">Alamat Email : </label>
            <input type="text" style="background-color: #dedede; width: 170px;" placeholder="lalayl@gmail.com" disabled><br><br>

            <?php $grandTotal = 0; ?>
            <?php foreach ($_SESSION["cart"] as $id_tiket => $kuantitas) : ?>
                <?php $tiket = query("SELECT * FROM jadwal_penerbangan INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai WHERE id_jadwal = '$id_tiket'")[0]; ?>

                <input type="hidden" name="id_penerbangan" value="<?= $id_tiket; ?>">
                <input type="hidden" name="jumlah_tiket" value="<?= $kuantitas; ?>">
                <input type="hidden" name="total_harga" value="<?= $tiket["harga"] * $kuantitas; ?>">

                <?php $grandTotal += $tiket["harga"] * $kuantitas; ?>
            <?php endforeach; ?>

            <h2>Grand Total <br>
            Rp. <?= number_format($grandTotal); ?></h2>
            <button type="submit" name="checkout" class="btn btn-success px-3 py-3"><i class="fa-solid fa-bag-shopping me-1"></i>  Checkout</button>
            </form>
        </div>
        </div>
    </div>
    </div>
</section>
             
<?php
    if (isset($_POST['checkout'])) {
        if (checkout($_POST) > 0) {
            echo "
                <script type='text/javascript'>
                    alert('barang berhasil dicheckout, silahkan tunggu proses verifikasi ya!');
                    window.location='index.php';
                </script>
            ";
        } else {
            
            echo mysqli_error($conn);
        }
    }
?>
    
</body>
</html>

<!-- section detail-breadcrumb -->

<!-- Section list tiket -->